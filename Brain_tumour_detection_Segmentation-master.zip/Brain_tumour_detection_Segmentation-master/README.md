# Brain_tumour_detection_Segmentation
Brain Tumor detection: Using UNET for image segmentation
- Classification Model -ResNET 
- UNET definition from Scratch
- Training Segmentaion model with RESNET as backbone to attain 95% accuracy on validation set [(Main code)](https://github.com/rajuzumaki2207/Brain_tumour_detection_Segmentation/blob/master/Brain_MRI_Detection_segmentation.ipynb)
- See the final prediction below

![Alt text](https://github.com/rajuzumaki2207/Brain_tumour_detection_Segmentation/blob/master/output.png?raw=true "Title")
